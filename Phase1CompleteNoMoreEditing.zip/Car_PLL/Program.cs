﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CAREntityLayer;
using CARException;
using Car_BLL;
using Car_DAL;
namespace Car_PLL
{
    class Program
    {
        static void Main(string[] args)
        {
            Car_BLL.CarBL.setlist();

            int choice;
            do
            {
                Print();
                Console.WriteLine("Enter your choice");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddcarPL();

                        break;
                    case 2:
                        ModifycarPL();

                        break;
                    case 3:
                        SearchcarPL();

                        break;
                    case 4:
                        RemovePL();

                        break;
                    case 5:
                        ShowallPL();

                        break;
                    case 6:

                        SetSerialization();
                        break;
                    case 7:
                        return;
                    default:
                        Console.WriteLine("invalid choice");
                        break;
                }

            } while (choice > 0 && choice < 8);

            Console.ReadKey();


        }

        public static void AddcarPL()
        {
            CarEntities car = new CarEntities();
            try
            {

                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Add CAR Details                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter Manufacturer Name");
                car.ManufacturerName = Console.ReadLine();
                Console.WriteLine("Enter Car Model");
                car.Model = Console.ReadLine();
                Console.WriteLine("Enter Car Type(Hatchback or Sedan or SUV)");
                car.Type = Console.ReadLine();
                Console.WriteLine("Enter Engine");
                car.Engine = Console.ReadLine();
                Console.WriteLine("Enter BHP");
                car.BHP = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Car Transmission (Manual/Automatic)");
                car.Transmission = Console.ReadLine();
                Console.WriteLine("Enter Mileage");
                car.Mileage = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter no. of seats");
                car.Seats = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Airbags details");
                car.Airbags = Console.ReadLine();
                Console.WriteLine("Enter BootSpace");
                car.BootSpace = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Price");
                car.price = double.Parse(Console.ReadLine());


                bool added = CarBL.AddBLL(car);
                if (added)
                    Console.WriteLine("Car Details are added successfully");
                else
                    Console.WriteLine("Details are not added ");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void ModifycarPL()
        {

            try
            {
                string model;
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Modify Car Details                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter  car Model");
                model = Console.ReadLine();
                CarEntities car = CarBL.SearchBLL(model);
                if (car != null)
                {
                    Console.WriteLine(" Manufacturer Name  :" + car.ManufacturerName);
                    Console.WriteLine(" Type  :" + car.Type);
                    Console.WriteLine(" Engine :" + car.Engine);
                    Console.WriteLine(" BHP :" + car.BHP);
                    Console.WriteLine(" Transmission :" + car.Transmission);
                    Console.WriteLine(" Mileage  :" + car.Mileage);
                    Console.WriteLine(" No.of Seats :" + car.Seats);
                    Console.WriteLine(" Airbag details  :" + car.Airbags);
                    Console.WriteLine(" BootSpace :" + car.BootSpace);
                    Console.WriteLine(" Price  :" + car.price);


                    Console.WriteLine("If you want to modify all details  press' 1 'or else '2' ");
                    int c = int.Parse(Console.ReadLine());
                    switch (c)
                    {
                        case 1:
                            Console.WriteLine("Enter Manufacturer Name");
                            car.ManufacturerName = Console.ReadLine();
                            Console.WriteLine("Enter Car Type(Hatchback or Sedan or SUV)");
                            car.Type = Console.ReadLine();
                            Console.WriteLine("Enter Engine");
                            car.Engine = Console.ReadLine();
                            Console.WriteLine("Enter BHP");
                            car.BHP = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Car Transmission (Manual/Automatic)");
                            car.Transmission = Console.ReadLine();
                            Console.WriteLine("Enter Mileage");
                            car.Mileage = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter no. of seats");
                            car.Seats = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Airbags details");
                            car.Airbags = Console.ReadLine();
                            Console.WriteLine("Enter BootSpace");
                            car.BootSpace = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Price");
                            car.price = double.Parse(Console.ReadLine());
                            bool modified = CarBL.ModifyBLL(car);
                            if (modified)
                                Console.WriteLine("Car Details are updated");
                            else
                                Console.WriteLine("Car Details are not updated");
                            break;
                        case 2:
                            Console.WriteLine("1.Manufacturer Name\n2.Type\n3.Engine\n4.BHP\n.5.Transmission\n6.Mileage\n7.No.of Seats\n8.Airbag details\n9.BootSpace\n10.Price");
                         
                                    break;
                           
                        default:
                            break;
                    }
                    int x = int.Parse(Console.ReadLine());
                    switch (x)
                    {
                        case 1:
                            Console.WriteLine("enter Manufacture Name");
                            car.ManufacturerName = Console.ReadLine();
                            bool modified = CarBL.ModifyBLL(car);
                            if (modified)
                                Console.WriteLine("Manufacture Name updated");
                            else
                                Console.WriteLine("Manufacture Name not updated");
                            break;
                        case 2:
                            Console.WriteLine("Enter Car Type(Hatchback or Sedan or SUV)");
                            car.Type = Console.ReadLine();
                            bool type = CarBL.ModifyBLL(car);
                            if (type)
                                Console.WriteLine("Type updated");
                            else
                                Console.WriteLine("Type not updated");
                            break;
                        case 3:
                            Console.WriteLine("Enter Engine");
                            car.Engine = Console.ReadLine();
                            bool eng = CarBL.ModifyBLL(car);
                            if (eng)
                                Console.WriteLine("Engine updated");
                            else
                                Console.WriteLine("Engine Name not updated");
                            break;
                        case 4:
                            Console.WriteLine("Enter BHP");
                            car.BHP = int.Parse(Console.ReadLine());
                            bool bhp = CarBL.ModifyBLL(car);
                            if (bhp)
                                Console.WriteLine("BHP updated");
                            else
                                Console.WriteLine("BHP not updated");
                            break;
                        case 5:
                            Console.WriteLine("Enter Car Transmission (Manual/Automatic)");
                            car.Transmission = Console.ReadLine();
                            bool trans = CarBL.ModifyBLL(car);
                            if (trans)
                                Console.WriteLine("Transmission Name updated");
                            else
                                Console.WriteLine("Transmission Name not updated");
                            break;
                        case 6:
                            Console.WriteLine("Enter Mileage");
                            car.Mileage = int.Parse(Console.ReadLine());
                            bool mi = CarBL.ModifyBLL(car);
                            if (mi)
                                Console.WriteLine("Mileage updated");
                            else
                                Console.WriteLine("Mileage not updated");
                            break;
                        case 7:
                            Console.WriteLine("Enter no. of seats");
                            car.Seats = int.Parse(Console.ReadLine());
                            bool seat = CarBL.ModifyBLL(car);
                            if (seat)
                                Console.WriteLine("Number of seats updated");
                            else
                                Console.WriteLine("Number of seats not updated");
                            break;
                        case 8:
                            Console.WriteLine("Enter Airbags details");
                            car.Airbags = Console.ReadLine();
                            bool bag = CarBL.ModifyBLL(car);
                            if (bag)
                                Console.WriteLine("Airbags detailsupdated");
                            else
                                Console.WriteLine("Airbags details not updated");
                            break;
                        case 9:
                            Console.WriteLine("Enter BootSpace");
                            car.BootSpace = int.Parse(Console.ReadLine());
                            bool bs = CarBL.ModifyBLL(car);
                            if (bs)
                                Console.WriteLine("Bootspace updated");
                            else
                                Console.WriteLine("BootSpace not updated");
                            break;
                        case 10:
                            Console.WriteLine("Enter Price");
                            car.price = double.Parse(Console.ReadLine());
                            bool pr = CarBL.ModifyBLL(car);
                            if (pr)
                                Console.WriteLine("Price updated");
                            else
                                Console.WriteLine("Price not updated");
                            break;
                        default:
                            Console.WriteLine("Invalid choice");
                            break;
                    }
                }
                else
                    Console.WriteLine("No car details available");
            }

            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }

        public static void SearchcarPL()
        {
            string model;

            try
            {

                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Search car                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter  car Model");
                model = Console.ReadLine();
                CarEntities car = CarBL.SearchBLL(model);
                if (car != null)
                {
                    Console.WriteLine("Car is found");
                    Console.WriteLine("*****************************************************************************");
                    Console.WriteLine(car.ManufacturerName + "\t" + car.Model + "\t" + car.Type + "\t" + car.price);
                    Console.WriteLine("*****************************************************************************");

                }
                else
                    Console.WriteLine("No Car details found");

            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void RemovePL()
        {
            try
            {
                string model;

                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Remove Car Details                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter  car Model");
                model = Console.ReadLine();
                CarEntities car = CarBL.SearchBLL(model);
                if (car != null)
                {
                    Console.WriteLine(" Are you sure to delete \t" + model + "\tenter 1 for Yes or 2 for No");
                    int x = int.Parse(Console.ReadLine());
                    switch (x)
                    {
                        case 1:
                            bool removedcar = CarBL.RemoveBLL(model);

                            if (removedcar)
                                Console.WriteLine("Car Details are removed successfully");
                            else
                                Console.WriteLine("Details are not removed as details are not found ");

                            break;
                        case 2:
                            break;
                        default:
                            Console.WriteLine("Invalid choice");
                            break;

                    }
                }
                else
                {
                    Console.WriteLine("Invalid Customer ID");
                }
            }
            

            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


        }

        public static void ShowallPL()
        {

            try
            {
                List<CarEntities> carlist = Car_BLL.CarBL.ShowBLL();
                if (carlist != null && carlist.Count > 0)
                {
                    Console.Clear();
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("                                List of  all Cars                           ");
                    Console.WriteLine("************************************************************************************");
                    carlist = CarBL.ShowBLL();

                    Console.WriteLine("*********************************************************************************");
                    Console.WriteLine("ManufacturerName\tModel\t\tType\t\tPrice");
                    Console.WriteLine("*********************************************************************************");
                    foreach (CarEntities car in carlist)
                    {


                        Console.WriteLine(car.ManufacturerName + "\t\t" + car.Model + "\t\t" + car.Type + "\t\t" + car.price);
                    }

                }
                else
                    Console.WriteLine("No car details available");

            }


            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void Print()
        {
            Console.WriteLine("************************************************************************************");
            Console.WriteLine("                                 Car Details                           ");
            Console.WriteLine("************************************************************************************");
            Console.WriteLine("1. Add Car ");
            Console.WriteLine("2. Modify car");
            Console.WriteLine("3. Search Car");
            Console.WriteLine("4. Remove car");
            Console.WriteLine("5. Show list");
            Console.WriteLine("6. Serialization");
            Console.WriteLine("7. Exit");


        }


        private static void SetSerialization()
        {
            try
            {
                Car_BLL.CarBL.SetSerialization();
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}
