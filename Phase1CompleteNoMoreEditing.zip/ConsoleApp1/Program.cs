﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CAREntityLayer;
using CARException;
using CIMSBLL;
using CIMSDAL;

namespace ConsoleApp1
{
    class Program
    {

        static void Main(string[] args)
        {
            CarBLL.setlist();

            int choice;
            do
            {
                Menu();
                Console.WriteLine("Enter Choice :");
                choice = Int32.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Admin();
                        break;
                    case 2:
                        Customer();
                        break;
                    case 3:
                        break;

                    default:

                        Console.WriteLine("Entered Wrong Choice\n");
                        break;
                }

            } while (choice != 3);



        }

        private static void Menu()
        {
            Console.WriteLine("\n***********Car Information Management System ***********");
            Console.WriteLine("1. Admin");
            Console.WriteLine("2. Customer");
            Console.WriteLine("3. Exit");
        }

        private static void Admin()
        {
            Console.WriteLine("\n***********Car Information Management System ***********");
            int ch;
            do
            {

                Console.WriteLine("\n\n1.Add Vehicle");
                Console.WriteLine("2.AddManufaturer");
                Console.WriteLine("3.Add trans");
                Console.WriteLine("4.add Type");
                Console.WriteLine("5.List all Vehicle");
                Console.WriteLine("6.Search By Model");
                Console.WriteLine("7.Search By ManufacturerName");
                Console.WriteLine("8.Update Model details");
                Console.WriteLine("9.Delete By Model");
                Console.WriteLine("10.Exit");
                Console.WriteLine("Enter Your Choice\n");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        AddVehicle();
                        break;

                    case 2:
                        AddManf();
                        break;

                    case 3:
                        AddTrans();
                        break;

                    case 4:
                        AddType();
                        break;
                       
                    case 5:
                        ListAllVehicle();
                        break;
                    case 6:
                        SearchVehiclebymodel();
                        break;
                    case 7:
                        SearchByManf();
                        break;
                    case 8:
                        UpdateCar();
                        break;
                    case 9:
                        DeleteCar();
                        break;
                    default:
                        break;
                }
            } while (ch != 10);
        }

        private static void Customer()
        {
            Console.WriteLine("\n***********WelCome To Car Information Management System ***********");


            int ch;
            do
            {
                Console.WriteLine("\n\n1. Search Vehicle by Model");
                Console.WriteLine("2.Search Vehicle by ManufacturerName and CarType");
               
                Console.WriteLine("3. Exit");
                Console.WriteLine("Enter Your Choice\n");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        SearchVehiclebymodel();
                        break;

                    case 2:
                        SearchByManf();
                        break;

                   
                    default:
                        break;
                }
            } while (ch != 3);
        }
        private static void AddVehicle()
        {
            try
            {

                CarEntities vehicle = new CarEntities();
                // Console.WriteLine("Enter Vehicle ID :");
                //vehicle.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Vehicle Model :");
                vehicle.Model = Console.ReadLine();
                Console.WriteLine("Enter  ManfName :");
                vehicle.ManufacturerName = Console.ReadLine();
                //Console.WriteLine("Enter Dealer ID :");
                //vehicle.ManufacturerId = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter The Price :");
                vehicle.price = Double.Parse(Console.ReadLine());
                Console.WriteLine("Enter Type :");
                vehicle.Type = (Console.ReadLine());
                Console.WriteLine("Enter Engine :");
                vehicle.Engine = Console.ReadLine();
                Console.WriteLine("Enter Transmission :");
                vehicle.Transmission = Console.ReadLine();
                Console.WriteLine("Enter Mileage :");
                vehicle.Mileage = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter AirBags :");
                vehicle.Airbags = Console.ReadLine();
                Console.WriteLine("Enter BootSpace :");
                vehicle.BootSpace = int.Parse(Console.ReadLine());
                Console.WriteLine("EnterSeats :");
                vehicle.Seats = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter BHP :");
                vehicle.BHP = int.Parse(Console.ReadLine());
                vehicle.TypeId = CarBLL.SearchTypeIdBLL(vehicle.Type);
                vehicle.TransmissionId = CarBLL.SearvhTransIdBLL(vehicle.Transmission);
                     vehicle.ManufacturerId = CarBLL.SearchManfIddBLL(vehicle.ManufacturerName);


                bool vehicleAdded = CarBLL.AddVehicle(vehicle);
                if (vehicleAdded)
                    Console.WriteLine("Vehicle Added");

                else
                    Console.WriteLine("vehicle not Added");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }



        private static void AddManf()
        {
            try
            {

                Manufacturer manf = new Manufacturer();
                // Console.WriteLine("Enter Vehicle ID :");
                //vehicle.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  Model Id :");
                manf.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  ManfName :");
                manf.Name = Console.ReadLine();

                Console.WriteLine("Enter ContactPerson :");
                manf.ContactNo = (Console.ReadLine());
                Console.WriteLine("Enter RegisteredOffice :");
                manf.RegisteredOffice = (Console.ReadLine());
                bool manfAdded = CarBLL.AddManf(manf);
                if (manfAdded)
                    Console.WriteLine("Manufacturer Added");

                else
                    Console.WriteLine("Manufacturer not Added");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddTrans()
        {
            try
            {

                CarTransmissionType trans = new CarTransmissionType();
                // Console.WriteLine("Enter Vehicle ID :");
                //vehicle.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  Trans Id :");
                trans.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  TransName :");
                trans.TransmissionType = Console.ReadLine();

                bool transadded = CarBLL.AddTrans(trans);
                if (transadded)
                    Console.WriteLine("Transmission Added");

                else
                    Console.WriteLine("Transmission not Added");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddType()
        {
            try
            {

                CarType type = new CarType();
                // Console.WriteLine("Enter Vehicle ID :");
                //vehicle.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  Type Id :");
                type.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  Type Name :");
                type.TypeOfCar = Console.ReadLine();

                bool transadded = CarBLL.AddType(type);
                if (transadded)
                    Console.WriteLine("Type Added");

                else
                    Console.WriteLine("Type not Added");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void ListAllVehicle()
        {

            try
            {
                List<CarEntities> vehiclelist = CarBLL.GetAllVehiclesBL();
                if (vehiclelist != null && vehiclelist.Count > 0)
                {
                    Console.WriteLine("********************************************************************************************************************");
                    Console.WriteLine("CarModel ManufId TransId TypeId  Price  Engine Seats   Type");
                    Console.WriteLine("*****************************************************************************************************************");
                    foreach (CarEntities vehicle in vehiclelist)
                    {
                        Console.WriteLine("{0}\t {1}\t {2}\t {3}\t {4}\t {5}\t {6}\t{7}", vehicle.Model, vehicle.ManufacturerId, vehicle.TransmissionId, vehicle.TypeId, vehicle.price,vehicle.Engine,vehicle.Seats,vehicle.Type);
                    }
                    Console.WriteLine("*****************************************************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Vehicle Details Available");
                }
            }
            catch (Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void SearchVehiclebymodel()
        {
            try
            {
                string model;
                Console.WriteLine("Enter Car Model to Search:");
                model = Console.ReadLine();
                CarEntities searchVehicle = CarBLL.SearchByModelBL(model);
                if (searchVehicle != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("CarModel ManufId TransId TypeId  Price  Engine Seats   Type");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t {1}\t {2}\t {3}\t {4} \t{5}\t{6}\t{7}", searchVehicle.Model, searchVehicle.ManufacturerId, searchVehicle.TransmissionId, searchVehicle.TypeId, searchVehicle.price,searchVehicle.Engine,searchVehicle.Seats,searchVehicle.Type);
                    Console.WriteLine("******************************************************************************");


                }
                else
                {
                    Console.WriteLine("No car Details Available");
                }

            }
            catch (Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchByManf()
        {
            try
            {
                string manfname;
                Console.WriteLine("Enter Manufacturer Name to Search:");
                manfname = Console.ReadLine();
                Console.WriteLine("Enter Car type  to Search:");
                 string cartype = Console.ReadLine();
                CarEntities searchVehicle = CarBLL.SearchByManflBL(manfname,cartype);
                if (searchVehicle != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("CarModel ManufId TransId TypeId  Price  Engine Seats   Type");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t {1}\t {2}\t {3}\t {4} \t{5}\t{6}\t{7}", searchVehicle.Model, searchVehicle.ManufacturerId, searchVehicle.TransmissionId, searchVehicle.TypeId, searchVehicle.price, searchVehicle.Engine, searchVehicle.Seats, searchVehicle.Type);
                    Console.WriteLine("******************************************************************************");


                }
                else
                {
                    Console.WriteLine("No Car Details Available");
                }

            }
            catch (Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateCar()
        {
            try
            {
                string updatemodel;
                Console.WriteLine("Enter Car Model to Update:");
                updatemodel = (Console.ReadLine());
                CarEntities ToUpdate = CarBLL.SearchByModelBL(updatemodel);

                if (ToUpdate != null)
                {
                    Console.WriteLine(" Manufacturer Name  :" + ToUpdate.ManufacturerName);
                    Console.WriteLine(" Type  :" + ToUpdate.Type);
                    Console.WriteLine(" Engine :" + ToUpdate.Engine);
                    Console.WriteLine(" BHP :" + ToUpdate.BHP);
                    Console.WriteLine(" Transmission :" + ToUpdate.Transmission);
                    Console.WriteLine(" Mileage  :" + ToUpdate.Mileage);
                    Console.WriteLine(" No.of Seats :" + ToUpdate.Seats);
                    Console.WriteLine(" Airbag details  :" + ToUpdate.Airbags);
                    Console.WriteLine(" BootSpace :" + ToUpdate.BootSpace);
                    Console.WriteLine(" Price  :" + ToUpdate.price);
                    Console.WriteLine("Enter  ManfName :");

                    Console.WriteLine("1. Update all details");
                    Console.WriteLine("2. Update manufacturer details");
                    Console.WriteLine("3. Update  Cartype ");
                    Console.WriteLine("4. Update Transmission type");

                    int c = int.Parse(Console.ReadLine());
                    switch (c)
                    {
                        case 1:
                            Console.WriteLine("Enter Manufacturer Name ");
                            ToUpdate.ManufacturerName = Console.ReadLine();

                            //vehicle.ManufacturerId = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter The Price :");
                            ToUpdate.price = Double.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Type :");
                            ToUpdate.Type = (Console.ReadLine());
                            Console.WriteLine("Enter Engine :");
                            ToUpdate.Engine = Console.ReadLine();
                            Console.WriteLine("Enter Transmission :");
                            ToUpdate.Transmission = Console.ReadLine();
                            Console.WriteLine("Enter Mileage :");
                            ToUpdate.Mileage = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter AirBags :");
                            ToUpdate.Airbags = Console.ReadLine();
                            Console.WriteLine("Enter BootSpace :");
                            ToUpdate.BootSpace = int.Parse(Console.ReadLine());
                            Console.WriteLine("EnterSeats :");
                            ToUpdate.Seats = int.Parse(Console.ReadLine());

                            Console.WriteLine("Enter BHP :");
                            ToUpdate.BHP = int.Parse(Console.ReadLine());
                            ToUpdate.TypeId = CIMSDAL.CarDal.SearchTypeIdDAL(ToUpdate.Type);
                            ToUpdate.TransmissionId = CIMSDAL.CarDal.SearchTransIdDAL(ToUpdate.Transmission);
                            ToUpdate.ManufacturerId = CIMSDAL.CarDal.SearchManfIdDAL(ToUpdate.ManufacturerName);
                            bool carUpdated = CarBLL.UpdateVehicleBL(ToUpdate);
                            if (carUpdated)
                            {
                                Console.WriteLine("Model Details Updated successfully !!!");
                            }
                            else
                            {
                                Console.WriteLine("Model Details not Updated ");
                            }
                            break;
                        case 2:
                            Console.WriteLine("Enter Manufacturer Name ");
                            ToUpdate.ManufacturerName = Console.ReadLine();
                            ToUpdate.ManufacturerId = CIMSDAL.CarDal.SearchManfIdDAL(ToUpdate.ManufacturerName);
                            bool Updatemanf = CarBLL.UpdateVehicleBL(ToUpdate);
                            if (Updatemanf)
                            {
                                Console.WriteLine("Model Details Updated successfully !!!");
                            }
                            else
                            {
                                Console.WriteLine("Model Details not Updated ");
                            }
                            break;

                        case 3:
                            Console.WriteLine("Enter Type :");
                            ToUpdate.Type = (Console.ReadLine());
                            ToUpdate.TypeId = CIMSDAL.CarDal.SearchTypeIdDAL(ToUpdate.Type);
                            
                            bool updatetype = CarBLL.UpdateVehicleBL(ToUpdate);
                            if (updatetype)
                            {
                                Console.WriteLine("Model Details Updated successfully !!!");
                            }
                            else
                            {
                                Console.WriteLine("Model Details not Updated ");
                            }
                            break;
                        case 4:
                            Console.WriteLine("Enter Type :");
                            ToUpdate.Transmission = (Console.ReadLine());
                            ToUpdate.TransmissionId = CIMSDAL.CarDal.SearchTypeIdDAL(ToUpdate.Type);

                            bool updatetrans = CarBLL.UpdateVehicleBL(ToUpdate);
                            if (updatetrans)
                            {
                                Console.WriteLine("Model Details Updated successfully !!!");
                            }
                            else
                            {
                                Console.WriteLine("Model Details not Updated ");
                            }
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Model Details are not  available");
                }
            }
            
            catch (Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteCar()
        {
            try
            {
                string model;

                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Remove Car Details                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter  car Model");
                model = Console.ReadLine();
                CarEntities car = CarBLL.SearchByModelBL(model);
                if (car != null)
                {
                    Console.WriteLine(" Are you sure to delete \t" + model + "\tenter 1 for Yes or 2 for No");
                    int x = int.Parse(Console.ReadLine());
                    switch (x)
                    {
                        case 1:
                            bool removedcar = CarBLL.DeleteCarBLL(model);

                            if (removedcar)
                                Console.WriteLine("Car Details are removed successfully");
                            else
                                Console.WriteLine("Details are not removed as details are not found ");

                            break;
                        case 2:
                            break;
                        default:
                            Console.WriteLine("Invalid choice");
                            break;

                    }
                }
                else
                {
                    Console.WriteLine("Invalid Car Model");
                }
            }


            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


        }


    }   
}

