﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIMSBLL;
using CAREntityLayer;
using CARException;


namespace CIMSPL
{
    public class CarPLL
    {
        static void Main(string[] args)
        {


            int choice;
            do
            {
                Menu();
                Console.WriteLine("Enter Choice :");
                choice = Int32.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Admin();
                        break;
                    //case 2:
                    //    Customer();
                    //    break;
                    case 3:
                        break;

                    default:

                        Console.WriteLine("Entered Wrong Choice\n");
                        break;
                }

            } while (choice != 3);



        }

        private static void Menu()
        {
            Console.WriteLine("\n***********Online Vehicle Showroom ***********");
            Console.WriteLine("1. Admin");
            Console.WriteLine("2. Customer");
            Console.WriteLine("3. Exit");
        }

        private static void Admin()
        {
            Console.WriteLine("\n***********Online Vehicle Showroom***********");
            int ch;
            do
            {

                Console.WriteLine("\n\n1.Add Vehicle");
                Console.WriteLine("2.AddManufaturer");
                Console.WriteLine("3.Add trans");
                Console.WriteLine("4.add Type");
                Console.WriteLine("5.Update Vehicle");
                Console.WriteLine("6.Exit");
                Console.WriteLine("Enter Your Choice\n");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        AddVehicle();
                        break;

                    case 2:
                        AddManf();
                        break;

                    case 3:
                        AddTrans();
                        break;

                    case 4:
                        AddType();
                        break;

                    //case 5:
                    //    UpdateVehicle();
                    //    bre

                    default:
                        break;
                }
            } while (ch != 6);
        }


        private static void AddVehicle()
        {
            try
            {

                CarEntities vehicle = new CarEntities();
                // Console.WriteLine("Enter Vehicle ID :");
                //vehicle.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Vehicle Model :");
                vehicle.Model = Console.ReadLine();
                Console.WriteLine("Enter  ManfName :");
                vehicle.ManufacturerName = Console.ReadLine();
                //Console.WriteLine("Enter Dealer ID :");
                //vehicle.ManufacturerId = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter The Price :");
                vehicle.price = Double.Parse(Console.ReadLine());
                Console.WriteLine("Enter Type :");
                vehicle.Type = (Console.ReadLine());
                Console.WriteLine("Enter Engine :");
                vehicle.Engine = Console.ReadLine();
                Console.WriteLine("Enter Transmission :");
                vehicle.Transmission = Console.ReadLine();
                Console.WriteLine("Enter Mileage :");
                vehicle.Mileage = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter AirBags :");
                vehicle.Airbags = Console.ReadLine();
                Console.WriteLine("Enter BootSpace :");
                vehicle.BootSpace = int.Parse(Console.ReadLine());
                Console.WriteLine("EnterSeats :");
                vehicle.Seats = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter BHP :");
                vehicle.BHP = int.Parse(Console.ReadLine());
                bool vehicleAdded = CarBLL.AddVehicle(vehicle);
                if (vehicleAdded)
                    Console.WriteLine("Vehicle Added");

                else
                    Console.WriteLine("vehicle not Added");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }



        private static void AddManf()
        {
            try
            {

                Manufacturer manf = new Manufacturer();
                // Console.WriteLine("Enter Vehicle ID :");
                //vehicle.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  Model Id :");
                manf.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  ManfName :");
                manf.Name = Console.ReadLine();

                Console.WriteLine("Enter ContactPerson :");
                manf.ContactNo = (Console.ReadLine());
                Console.WriteLine("Enter RegisteredOffice :");
                manf.RegisteredOffice = (Console.ReadLine());
                bool manfAdded = CarBLL.AddManf(manf);
                if (manfAdded)
                    Console.WriteLine("Manufacturer Added");

                else
                    Console.WriteLine("Manufacturer not Added");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddTrans()
        {
            try
            {

                CarTransmissionType trans = new CarTransmissionType();
                // Console.WriteLine("Enter Vehicle ID :");
                //vehicle.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  Trans Id :");
                trans.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  TransName :");
                trans.TransmissionType = Console.ReadLine();

                bool transadded = CarBLL.AddTrans(trans);
                if (transadded)
                    Console.WriteLine("Transmission Added");

                else
                    Console.WriteLine("Transmission not Added");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddType()
        {
            try
            {

                CarType type = new CarType();
                // Console.WriteLine("Enter Vehicle ID :");
                //vehicle.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  Trans Id :");
                type.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter  TransName :");
                type.TypeOfCar = Console.ReadLine();

                bool transadded = CarBLL.AddType(type);
                if (transadded)
                    Console.WriteLine("Type Added");

                else
                    Console.WriteLine("Type not Added");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
