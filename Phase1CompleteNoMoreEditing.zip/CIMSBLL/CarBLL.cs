﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CARException;
using CAREntityLayer;
using CIMSDAL;
using System.Text.RegularExpressions;
using System.IO;

namespace CIMSBLL
{
    public class CarBLL
    {

        public static bool Validate(CarEntities car)
        {
            bool validate = true;
            try
            {
                StringBuilder sb = new StringBuilder();
                if (SearchByModelBL(car.Model) != null)
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Car Model already exists");
                }
                if (SearchManfIddBLL(car.ManufacturerName) == 0)
                {
                    validate = false;
                    sb.Append(Environment.NewLine +  "Manufacturer not present");


                }
                
              
                if (car.Type != "Hatchback" && car.Type != "SUV" && car.Type != "Sedan")
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Type name should be Hatchback or Sedan or SUV");
                }
                if (!(Regex.IsMatch(car.Engine, @"^\d\.\dL$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Engine name should have 4 characters with 1st and 3rd character number ,2nd '.' and last 'L'");

                }
                if (!(Regex.IsMatch(car.BHP.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "BHP should be a number");
                }
                if (car.Transmission != "Manual" && car.Transmission != "Automatic")
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Should be either Manual or Automatic");
                }
                if (!(Regex.IsMatch(car.Mileage.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Mileage should be a number");
                }
                if (!(Regex.IsMatch(car.Seats.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "seats should be a number");
                }
                if (!(Regex.IsMatch(car.Airbags, @"^[A-Za-z]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Airbags details should be a string");
                }
                if (!(Regex.IsMatch(car.BootSpace.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Bootspace should be a number with 3 digits");
                }
                if (!(Regex.IsMatch(car.price.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Price should be a number");
                }
                
                if (!(Regex.IsMatch(car.Model, @"^[A-Z][a-z]{2,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Model should contain characters with First character Caps");
                    
                }
                if (car.ManufacturerName == String.Empty || car.Mileage.ToString() == String.Empty || car.Model == String.Empty || car.Seats.ToString() == String.Empty || car.price.ToString() == String.Empty || car.Transmission == String.Empty || car.Type == String.Empty || car.BootSpace.ToString() == String.Empty || car.Airbags == String.Empty)
                {
                    validate = false;
                    sb.AppendLine("All Fields are  mandatory");
                }
                if (validate == false)

                    throw new CARException.Myexception(sb.ToString());
            }
            catch (Myexception ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
            return validate;

        }

        public static bool ValidateManf(Manufacturer manf)
        {
            bool validate = true;
            try
            {
                if (!(Regex.IsMatch(manf.Name, @"^[A-Z]{1}[a-z]{2,}$")))
                {
                    validate = false;
                   Console.WriteLine( "Manufacturer name should contain only alphabets and First letter should be in Caps");

                }
            }
            catch (Myexception ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
            return validate;

        }


        public static void setlist()
        {
            try
            {
                if (File.Exists(Directory.GetCurrentDirectory() + "\\" + CarDal.fileName))
                {
                    CarDal.SetlistDL();
                }
                if (File.Exists(Directory.GetCurrentDirectory() + "\\" + CarDal.fileName1))
                {
                    CarDal.SetlistDL();
                }
                if (File.Exists(Directory.GetCurrentDirectory() + "\\" + CarDal.fileName2))
                {
                    CarDal.SetlistDL();
                }
                if (File.Exists(Directory.GetCurrentDirectory() + "\\" + CarDal.fileName3))
                {
                    CarDal.SetlistDL();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static bool AddVehicle(CarEntities car)
        {
            bool vehicleAdded = false;
            try
            {
                if (Validate(car))
                {
                    vehicleAdded = CarDal.AddCarDAL(car);
                }
            }
            catch (CARException.Myexception e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return vehicleAdded;
        }

        public static List<CarEntities> GetAllVehiclesBL()
        {
            List<CarEntities> vehiclelist = null;
            try
            {
                vehiclelist = CarDal.GetAllVehicleDL();
            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return vehiclelist;
        }

        public static bool AddManf(Manufacturer manf)
        {
            bool ManfAdded = false;
            try
            {
                if (ValidateManf(manf))
                    {
                    ManfAdded = CarDal.AddManfDAL(manf);
                }
                

            }
            catch (CARException.Myexception e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ManfAdded;
        }
        public static bool AddType(CarType car)
        {
            bool typeAdded = false;
            try
            {
                typeAdded = CarDal.AddTypeDAL(car);

            }
            catch (CARException.Myexception e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return typeAdded;
        }
        public static bool AddTrans(CarTransmissionType car)
        {
            bool transadded = false;
            try
            {
              
                transadded = CarDal.AddTransDAL(car);

            }
            catch (CARException.Myexception e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return transadded;
        }
        public static CarEntities SearchByModelBL(string model)
        {
            CarEntities searchVehicle = null;
            try
            {
                searchVehicle =   CarDal.SearchVehicleByModelDAL(model);
            }
            catch (Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVehicle;
        }

        public static CarEntities SearchByManflBL(string manfname,string cartype)
        {
            CarEntities searchVehicle = null;
            try
            {
                searchVehicle = CarDal.SearchByManufDAL(manfname, cartype);
            }
            catch (Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVehicle;
        }
        public static int SearchTypeIdBLL( string cartype)
        {
            int  typeId = 0;
            try
            {
                typeId = CarDal.SearchTypeIdDAL( cartype);
            }
            catch (Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return typeId;
        }
        public static int SearchManfIddBLL(string manfname)
        {
            int ManfId = 0;
            try
            {
                ManfId = CarDal.SearchManfIdDAL(manfname);
            }
            catch (Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ManfId;
        }
        public static int SearvhTransIdBLL(string transname)
        {
            int TransId = 0;
            try
            {
                TransId = CarDal.SearchTypeIdDAL(transname);
            }
            catch (Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return TransId;
        }
        public static bool UpdateVehicleBL(CarEntities updatecar)
        {
            bool vehicleupdated = false;
            try
            {
                if (Validate(updatecar))
                {

                    vehicleupdated = CarDal.UpdateVehicleDAL(updatecar);
                }

            }
            catch (Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return vehicleupdated;
        }

        public static bool DeleteCarBLL(string model)
        {
            bool removed = false;
            try
            {
                if (model != string.Empty)
                {
                    removed = CarDal.DeleteCarDAL(model);
                }
               

            }
            catch (Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return removed;
        }

    }
}
