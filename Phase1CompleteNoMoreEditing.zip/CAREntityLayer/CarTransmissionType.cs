﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CAREntityLayer
{

    [Serializable]
  public  class CarTransmissionType
    {
        public int Id { get; set; }
        public string TransmissionType { get; set; }
       
    }
}
